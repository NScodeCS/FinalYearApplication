package com.example.fyp5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.rengwuxian.materialedittext.MaterialEditText;

public class RegisterActivity extends AppCompatActivity {

    MaterialEditText phonenumber,c_number;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        phonenumber = findViewById(R.id.number);
        c_number = findViewById(R.id.confirmnumber);
        register = findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


    }

    private void registerNewAccount(String number,String c_number ){
        ProgressDialog progressDialog = new ProgressDialog( RegisterActivity.this );
        progressDialog.setCancelable(false);
        progressDialog.setIndeterminate(false);
        progressDialog.setTitle("Register New User");
        progressDialog.show();
        String uRL = "http:/10.0.2.2"

    }
}
